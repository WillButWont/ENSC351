#include "reaction_timer.h"
#include "hal/joystick.h"
#include "hal/led.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>

#define FLASH_DELAY_MS 250
#define REACTION_TIMEOUT_MS 5000
#define GREEN_LED LED_UP    // ACT LED
#define RED_LED   LED_DOWN  // PWR LED

// Helper to get current time in milliseconds
static long get_time_ms(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (tv.tv_sec * 1000L) + (tv.tv_usec / 1000L);
}

// Helper delay (ms)
static void delay_ms(int ms)
{
    usleep(ms * 1000);
}

// Flash LEDs alternately for “get ready”
static void flash_ready_sequence(void)
{
    printf("Get ready...\n");
    for (int i = 0; i < 4; i++) {
        LED_turnOn(GREEN_LED);
        delay_ms(FLASH_DELAY_MS);
        LED_allOff();

        LED_turnOn(RED_LED);
        delay_ms(FLASH_DELAY_MS);
        LED_allOff();
    }
}

void ReactionTimer_run(void)
{
    srand(time(NULL));

    printf("Hello embedded world, from William The!\n");
    printf("When the LEDs light up, press the joystick in that direction!\n");
    printf("(Press left or right to exit)\n");

    int best_time = -1;
    int told_to_let_go = 0;

    while (1) {
        flash_ready_sequence();

        // Step 2: Check if joystick is held up/down
        JoystickDirection dir = Joystick_getDirection();
        if (dir == JS_UP || dir == JS_DOWN) {
            if (!told_to_let_go) {
                printf("Please let go of joystick.\n");
                told_to_let_go = 1;
            }
            while (dir == JS_UP || dir == JS_DOWN) {
                dir = Joystick_getDirection();
                usleep(50000);
            }
        }
        told_to_let_go = 0;

        // Step 3: Wait random delay between 0.5s and 3.0s
        double delay_s = 0.5 + ((double)rand() / RAND_MAX) * 2.5;
        usleep((int)(delay_s * 1e6));

        // Step 4: If pressing too soon
        dir = Joystick_getDirection();
        if (dir == JS_UP || dir == JS_DOWN) {
            printf("Too soon!\n");
            continue;  // restart loop
        }

        // Step 5: Pick random direction
        JoystickDirection target = (rand() % 2 == 0) ? JS_UP : JS_DOWN;
        if (target == JS_UP) {
            printf("Press UP now!\n");
            LED_turnOn(GREEN_LED);
        } else {
            printf("Press DOWN now!\n");
            LED_turnOn(RED_LED);
        }

        // Step 6: Time user’s reaction
        long start = get_time_ms();
        JoystickDirection input = JS_NONE;

        while (1) {
            input = Joystick_getDirection();
            long elapsed = get_time_ms() - start;

            if (input != JS_NONE) break;
            if (elapsed > REACTION_TIMEOUT_MS) {
                printf("No input within %dms; quitting!\n", REACTION_TIMEOUT_MS);
                LED_allOff();
                return;
            }
            usleep(10000);
        }

        LED_allOff();

        // Step 7: Process joystick press
        if (input == JS_LEFT || input == JS_RIGHT) {
            printf("User selected to quit.\n");
            break;
        }

        long reaction_time = get_time_ms() - start;

        if (input == target) {
            printf("Correct!\n");
            if (best_time == -1 || reaction_time < best_time) {
                best_time = reaction_time;
                printf("New best time!\n");
            }
            printf("Your reaction time was %ldms; best so far in game is %dms.\n",
                   reaction_time, best_time);

            // Flash green LED 5 times in 1s
            for (int i = 0; i < 5; i++) {
                LED_turnOn(GREEN_LED);
                delay_ms(100);
                LED_allOff();
                delay_ms(100);
            }
        } else {
            printf("Incorrect.\n");

            // Flash red LED 5 times in 1s
            for (int i = 0; i < 5; i++) {
                LED_turnOn(RED_LED);
                delay_ms(100);
                LED_allOff();
                delay_ms(100);
            }
        }
    }

    LED_allOff();
}
