#include "reaction_timer.h"
#include "hal/joystick.h"
#include "hal/led.h"

int main(void)
{
    Joystick_init();
    LED_init();

    ReactionTimer_run();

    Joystick_cleanup();
    LED_cleanup();
    return 0;
}
