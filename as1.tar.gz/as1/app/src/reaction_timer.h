#ifndef REACTION_TIMER_H
#define REACTION_TIMER_H

void ReactionTimer_run(void);

#endif
