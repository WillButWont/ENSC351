#define _GNU_SOURCE
#include "hal/audioMixer.h"
#include "hal/udpServer.h"
#include "hal/accelerometer.h"
#include "hal/joystick.h"
#include "hal/rotaryEncoder.h"
#include "hal/periodTimer.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>


#define ROTARY_GPIO_CHIP "/dev/gpiochip2" 
#define ROTARY_PIN_A     15               
#define ROTARY_PIN_B     17               
#define ROTARY_PIN_BTN   7               

static volatile bool keepRunning = true;

// Thread to handle input polling (Joystick & Accelerometer)
 static pthread_t inputThreadId;


static void* inputThread(void* arg) {
    (void)arg;
    struct timespec sleepTime = {0, 10000000}; // 10ms polling rate 

    long long lastJoystickTime = 0;
    const long long JOYSTICK_REPEAT_DELAY_MS = 200; // Wait 200ms between volume changes

    while (keepRunning) {
        // Run every 10ms 
        Accel_readAndPlay();

        // Process Joystick
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        long long currentTimeMs = now.tv_sec * 1000 + now.tv_nsec / 1000000;

        if (currentTimeMs - lastJoystickTime > JOYSTICK_REPEAT_DELAY_MS) {
            joystick_dir_t dir = hal_joystick_read_direction();
            
            if (dir == JOY_UP) {
                AudioMixer_setVolume(AudioMixer_getVolume() + 5);
                lastJoystickTime = currentTimeMs; // Reset timer
            } 
            else if (dir == JOY_DOWN) {
                AudioMixer_setVolume(AudioMixer_getVolume() - 5);
                lastJoystickTime = currentTimeMs; // Reset timer
            }
        }

        nanosleep(&sleepTime, NULL);
    }
    return NULL;
}






int main(void) {
    printf("Starting Beat-Box...\n");

    // Initialize Hardware Abstraction Layer (HAL) 
    Period_init();
    
    // Initialize Audio 
    AudioMixer_init(); 
    
    UdpServer_init(12345, &keepRunning);

    // Initialize Sensors
    Accel_init();
    
   hal_joystick_init("/dev/spidev0.0", 250000);
    // Initialize Rotary Encoder 
    // Uses the new signature
    Rotary_init(ROTARY_GPIO_CHIP, ROTARY_PIN_A, ROTARY_PIN_B, ROTARY_PIN_BTN);

    // Start Input Polling Thread
    if (pthread_create(&inputThreadId, NULL, inputThread, NULL) != 0) {
        perror("Failed to start input thread");
        return 1;
    }

    // Main Loop 
    struct timespec oneSec = {1, 0};
    
    while (keepRunning) {
        nanosleep(&oneSec, NULL);

        // Get Statistics
        Period_statistics_t audioStats;
        Period_getStatisticsAndClear(PERIOD_EVENT_AUDIO_BUFFER, &audioStats);

        Period_statistics_t accelStats;
        Period_getStatisticsAndClear(PERIOD_EVENT_ACCEL_READ, &accelStats);

        // Get State
        int mode = AudioMixer_getMode();
        int bpm = AudioMixer_getBPM();
        int vol = AudioMixer_getVolume();

        // Print Status to Console
        printf("M%d %dbpm vol:%d  Audio[%.3f, %.3f] avg %.3f/%d  Accel[%.3f, %.3f] avg %.3f/%d\n",
            mode, bpm, vol,
            audioStats.minPeriodInMs, audioStats.maxPeriodInMs, audioStats.avgPeriodInMs, audioStats.numSamples,
            accelStats.minPeriodInMs, accelStats.maxPeriodInMs, accelStats.avgPeriodInMs, accelStats.numSamples
        );
    }

    // Cleanup
    printf("\nShutting down...\n");
    
    pthread_join(inputThreadId, NULL);
    
    Rotary_cleanup();
    Accel_cleanup();
    UdpServer_cleanup();
    AudioMixer_cleanup();
    Period_cleanup();

    printf("Done!\n");
    return 0;
}