#include "hal/udpServer.h"
#include "hal/audioMixer.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdbool.h>

#define MAX_BUFFER_LEN 1024

static pthread_t threadId;
static int socketFd = -1;
static volatile bool* stopProgramFlag = NULL;

static void* serverThread(void* arg) {
    (void)arg;
    char buffer[MAX_BUFFER_LEN];
    char reply[MAX_BUFFER_LEN];
    struct sockaddr_in cliAddr;
    socklen_t len = sizeof(cliAddr);

    while (stopProgramFlag && *stopProgramFlag) {
        memset(buffer, 0, MAX_BUFFER_LEN);
        memset(reply, 0, MAX_BUFFER_LEN);
        
        int n = recvfrom(socketFd, buffer, MAX_BUFFER_LEN - 1, 0, (struct sockaddr*)&cliAddr, &len);
        if (n < 0) continue;
        buffer[n] = '\0';

        printf("UDP CMD: '%s'\n", buffer);

        if (strncmp(buffer, "vol", 3) == 0) {
            // Parse Command
            if (strstr(buffer, "inc") || strstr(buffer, "up") || strstr(buffer, "+")) {
                AudioMixer_setVolume(AudioMixer_getVolume() + 5);
            } else if (strstr(buffer, "dec") || strstr(buffer, "down") || strstr(buffer, "-")) {
                AudioMixer_setVolume(AudioMixer_getVolume() - 5);
            } else {
                int val;
                if (sscanf(buffer, "%*s %d", &val) == 1) AudioMixer_setVolume(val);
            }
            // Reply with the volume number
            snprintf(reply, MAX_BUFFER_LEN, "%d", AudioMixer_getVolume());
            sendto(socketFd, reply, strlen(reply), 0, (struct sockaddr*)&cliAddr, len);
        }
        
        else if (strncmp(buffer, "tempo", 5) == 0) {
            if (strstr(buffer, "inc") || strstr(buffer, "up") || strstr(buffer, "+")) {
                AudioMixer_setBPM(AudioMixer_getBPM() + 5);
            } else if (strstr(buffer, "dec") || strstr(buffer, "down") || strstr(buffer, "-")) {
                AudioMixer_setBPM(AudioMixer_getBPM() - 5);
            } else {
                int val;
                if (sscanf(buffer, "%*s %d", &val) == 1) AudioMixer_setBPM(val);
            }
            snprintf(reply, MAX_BUFFER_LEN, "%d", AudioMixer_getBPM());
            sendto(socketFd, reply, strlen(reply), 0, (struct sockaddr*)&cliAddr, len);
        }
        
        else if (strncmp(buffer, "mode", 4) == 0 || strncmp(buffer, "beat", 4) == 0) {
            if (strstr(buffer, "none") || strstr(buffer, "0")) AudioMixer_setMode(0);
            else if (strstr(buffer, "rock") || strstr(buffer, "1")) AudioMixer_setMode(1);
            else if (strstr(buffer, "custom") || strstr(buffer, "2")) AudioMixer_setMode(2);
            
        
            snprintf(reply, MAX_BUFFER_LEN, "%d", AudioMixer_getMode());
            sendto(socketFd, reply, strlen(reply), 0, (struct sockaddr*)&cliAddr, len);
        }
        
        // Play Sound
        else if (strstr(buffer, "base") || strstr(buffer, "bd") || 
                 strstr(buffer, "snare") || strstr(buffer, "hihat") || strstr(buffer, "hat") ||
                 strncmp(buffer, "play", 4) == 0) {
            
            if (strstr(buffer, "base") || strstr(buffer, "bd")) AudioMixer_queueSound(&base);
            else if (strstr(buffer, "snare")) AudioMixer_queueSound(&snare);
            else if (strstr(buffer, "hihat") || strstr(buffer, "hat")) AudioMixer_queueSound(&hihat);
            
            snprintf(reply, MAX_BUFFER_LEN, "played");
            sendto(socketFd, reply, strlen(reply), 0, (struct sockaddr*)&cliAddr, len);
        }
        
        // Stop 
        else if (strncmp(buffer, "stop", 4) == 0) {
            if (stopProgramFlag) *stopProgramFlag = false;
            snprintf(reply, MAX_BUFFER_LEN, "Program Stopping");
            sendto(socketFd, reply, strlen(reply), 0, (struct sockaddr*)&cliAddr, len);
            break;
        }
        else {
     
        }
    }
    return NULL;
}

int UdpServer_init(int port, volatile bool* stopFlag) {
    stopProgramFlag = stopFlag;
    if ((socketFd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) return -1;
    
    struct sockaddr_in servAddr;
    memset(&servAddr, 0, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servAddr.sin_port = htons(port);

    if (bind(socketFd, (struct sockaddr*)&servAddr, sizeof(servAddr)) < 0) {
        close(socketFd);
        return -1;
    }

    if (pthread_create(&threadId, NULL, serverThread, NULL) != 0) {
        close(socketFd);
        return -1;
    }
    return 0;
}

void UdpServer_cleanup(void) {
    if (socketFd >= 0) {
        pthread_cancel(threadId);
        pthread_join(threadId, NULL);
        close(socketFd);
        socketFd = -1;
    }
}