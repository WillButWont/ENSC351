#define _GNU_SOURCE
#include "hal/rotaryEncoder.h"
#include "hal/audioMixer.h" 
#include <stdio.h>
#include <stdlib.h>
#include <stdatomic.h>
#include <pthread.h>
#include <time.h>
#include <gpiod.h>
#include <unistd.h>

#define DEBOUNCE_TIME_MS 200

static pthread_t th;
static atomic_int running = 0;
static struct gpiod_line_request *rq = NULL;
static struct gpiod_line_request *rq_btn = NULL;

static unsigned pinA, pinB, pinBtn;

// Helper to sleep
static void sleep_ms(int ms) {
    struct timespec ts = {ms / 1000, (ms % 1000) * 1000000L};
    nanosleep(&ts, NULL);
}

// Thread Loop
static void* rotary_loop(void* arg) {
    (void)arg;
    int prevA = gpiod_line_request_get_value(rq, pinA);
    
    long long lastBtnPress = 0;

    running = 1;
    while (atomic_load(&running)) {
        // Handle Rotation (Tempo) 
        int currA = gpiod_line_request_get_value(rq, pinA);
        int currB = gpiod_line_request_get_value(rq, pinB);
        
        if (currA != prevA) {
            // Logic: If A changed, check B to determine direction
            if (currA != currB) {
                // CW -> Tempo Up
                AudioMixer_setBPM(AudioMixer_getBPM() + 5);
            } else {
                // CCW -> Tempo Down
                AudioMixer_setBPM(AudioMixer_getBPM() - 5);
            }
        }
        prevA = currA;

        // Handle Button (Mode)
        // (0 = Pressed)
        int btn = gpiod_line_request_get_value(rq_btn, pinBtn);
        
        if (btn == 0) {
             struct timespec now;
             clock_gettime(CLOCK_MONOTONIC, &now);
             long long nowMs = now.tv_sec * 1000 + now.tv_nsec / 1000000;

             if (nowMs - lastBtnPress > DEBOUNCE_TIME_MS) { 
                 AudioMixer_nextMode(); // Cycle Rock/Custom/None
                 lastBtnPress = nowMs;
             }
        }

        sleep_ms(5); // Poll rate
    }
    return NULL;
}

void Rotary_init(const char* chip, unsigned pin_a, unsigned pin_b, unsigned pin_btn) {
    pinA = pin_a;
    pinB = pin_b;
    pinBtn = pin_btn;

    struct gpiod_chip *c = gpiod_chip_open(chip);
    if (!c) {
        perror("Rotary: Failed to open GPIO chip");
        return;
    }

    // Setup Rotary Pins (A & B) 
    struct gpiod_line_settings *ls = gpiod_line_settings_new();
    gpiod_line_settings_set_direction(ls, GPIOD_LINE_DIRECTION_INPUT);
    
    struct gpiod_line_config *lc = gpiod_line_config_new();
    unsigned offsets[2] = {pinA, pinB};
    gpiod_line_config_add_line_settings(lc, offsets, 2, ls);

    struct gpiod_request_config *rc = gpiod_request_config_new();
    gpiod_request_config_set_consumer(rc, "rotary");

    rq = gpiod_chip_request_lines(c, rc, lc);
    
    gpiod_request_config_free(rc);
    gpiod_line_config_free(lc);
    gpiod_line_settings_free(ls);

    if (!rq) {
        perror("Rotary: Failed to request lines");
        gpiod_chip_close(c);
        return;
    }

    // Setup Button Pin
    struct gpiod_line_settings *ls_btn = gpiod_line_settings_new();
    gpiod_line_settings_set_direction(ls_btn, GPIOD_LINE_DIRECTION_INPUT);
    gpiod_line_settings_set_bias(ls_btn, GPIOD_LINE_BIAS_PULL_UP);

    struct gpiod_line_config *lc_btn = gpiod_line_config_new();
    gpiod_line_config_add_line_settings(lc_btn, &pinBtn, 1, ls_btn);

    struct gpiod_request_config *rc_btn = gpiod_request_config_new();
    gpiod_request_config_set_consumer(rc_btn, "rotary_btn");

    rq_btn = gpiod_chip_request_lines(c, rc_btn, lc_btn);

    gpiod_request_config_free(rc_btn);
    gpiod_line_config_free(lc_btn);
    gpiod_line_settings_free(ls_btn);

    if (!rq_btn) {
        perror("Rotary: Failed to request button line");
        gpiod_chip_close(c);
        return;
    }

    gpiod_chip_close(c);

    pthread_create(&th, NULL, rotary_loop, NULL);
}

void Rotary_cleanup(void) {
    atomic_store(&running, 0);
    pthread_join(th, NULL);
    if (rq) gpiod_line_request_release(rq);
    if (rq_btn) gpiod_line_request_release(rq_btn);
}