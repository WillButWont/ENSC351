#define _GNU_SOURCE 
#include <time.h>
#include "hal/periodTimer.h"
#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>


// Data collected for each event type
typedef struct {
    long timestampCount;
    long long timestampsInNs[MAX_EVENT_TIMESTAMPS];
    long long prevTimestampInNs; // Used to calculate delta across analysis periods
} timestamps_t;

static timestamps_t s_eventData[NUM_PERIOD_EVENTS];
static pthread_mutex_t s_lock = PTHREAD_MUTEX_INITIALIZER;
static bool s_initialized = false;

// Helper prototypes
static void updateStats(timestamps_t *pData, Period_statistics_t *pStats);
static long long getTimeInNanoS(void);

void Period_init(void)
{
    pthread_mutex_lock(&s_lock);
    memset(s_eventData, 0, sizeof(s_eventData[0]) * NUM_PERIOD_EVENTS);
    s_initialized = true;
    pthread_mutex_unlock(&s_lock);
}

void Period_cleanup(void)
{
    pthread_mutex_lock(&s_lock);
    s_initialized = false;
    pthread_mutex_unlock(&s_lock);
}

void Period_markEvent(enum Period_whichEvent whichEvent)
{
    if (!s_initialized) return;
    assert(whichEvent >= 0 && whichEvent < NUM_PERIOD_EVENTS);

    pthread_mutex_lock(&s_lock);
    timestamps_t *pData = &s_eventData[whichEvent];
    if (pData->timestampCount < MAX_EVENT_TIMESTAMPS) {
        pData->timestampsInNs[pData->timestampCount] = getTimeInNanoS();
        pData->timestampCount++;
    }
    pthread_mutex_unlock(&s_lock);
}

void Period_getStatisticsAndClear(enum Period_whichEvent whichEvent, Period_statistics_t *pStats)
{
    if (!s_initialized) return;
    assert(whichEvent >= 0 && whichEvent < NUM_PERIOD_EVENTS);
    
    pthread_mutex_lock(&s_lock);
    timestamps_t *pData = &s_eventData[whichEvent];

    // Compute stats based on the data collected since the last clear
    updateStats(pData, pStats);

    // Save the last timestamp to calculate the delta for the next period
    if (pData->timestampCount > 0) {
        pData->prevTimestampInNs = pData->timestampsInNs[pData->timestampCount - 1];
    }

    // Reset the count for the next batch
    pData->timestampCount = 0;
    pthread_mutex_unlock(&s_lock);
}

static void updateStats(timestamps_t *pData, Period_statistics_t *pStats)
{
    long long prevInNs = pData->prevTimestampInNs;

    // Handle startup case (no previous sample)
    if (prevInNs == 0 && pData->timestampCount > 0) { 
        prevInNs = pData->timestampsInNs[0];
    }
    
    long long sumDeltasNs = 0;
    long long minNs = 0;
    long long maxNs = 0;
    int num_deltas = 0;

    if (pData->timestampCount > 0) {
        // Calculate first delta against the previous batch's last sample
        long long thisTime = pData->timestampsInNs[0];
        long long deltaNs = thisTime - prevInNs;
        
        sumDeltasNs += deltaNs;
        minNs = deltaNs;
        maxNs = deltaNs;
        num_deltas = 1;
        prevInNs = thisTime;
    }

    // Process remaining samples in this batch
    for (int i = 1; i < pData->timestampCount; i++) {
        long long thisTime = pData->timestampsInNs[i];
        long long deltaNs = thisTime - prevInNs;
        sumDeltasNs += deltaNs;

        if (deltaNs < minNs) minNs = deltaNs;
        if (deltaNs > maxNs) maxNs = deltaNs;
        
        num_deltas++;
        prevInNs = thisTime;
    }

    long long avgNs = 0;
    if (num_deltas > 0) {
        avgNs = sumDeltasNs / num_deltas;
    } 

    // Convert to Milliseconds for the output struct
    #define MS_PER_NS (1000000.0) 
    pStats->minPeriodInMs = minNs / MS_PER_NS;
    pStats->maxPeriodInMs = maxNs / MS_PER_NS;
    pStats->avgPeriodInMs = avgNs / MS_PER_NS;
    pStats->numSamples = pData->timestampCount; 
}

static long long getTimeInNanoS(void) 
{
    struct timespec spec;
    clock_gettime(CLOCK_BOOTTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec + seconds * 1000LL * 1000LL * 1000LL;
    return nanoSeconds;
}