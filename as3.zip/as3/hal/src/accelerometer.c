#define _GNU_SOURCE
#include "hal/accelerometer.h"
#include "hal/spi_adc.h"
#include "hal/periodTimer.h"
#include "hal/audioMixer.h" 
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdio.h>


#define ACCEL_THRESHOLD 250 


#define DEBOUNCE_TIME_MS 150 

//wiring on the ADC chip (MCP3208)
static const int CHANNEL_X = 2; 
static const int CHANNEL_Y = 3;
static const int CHANNEL_Z = 4;

// Resting values 
static int restX = 2048;
static int restY = 2048;
static int restZ = 2048;

static int spi_fd = -1;

// Timers for debouncing each axis
static long long lastTriggerX = 0;
static long long lastTriggerY = 0;
static long long lastTriggerZ = 0;

// Helper to get current time in ms
static long long getTimeMs(void) {
    struct timespec spec;
    clock_gettime(CLOCK_MONOTONIC, &spec);
    return spec.tv_sec * 1000 + spec.tv_nsec / 1000000;
}

void Accel_init(void) {
    // Open the SPI device used by ADC chip
    spi_fd = hal_spi_adc_open("/dev/spidev0.0", 250000); 
    
    // Startup Calibration
    // Assumes the board is sitting flat on the desk when the program starts.
    if (spi_fd >= 0) {
        for(int i=0; i<5; i++) {
            restX = hal_spi_adc_read_ch(spi_fd, CHANNEL_X, 250000);
            restY = hal_spi_adc_read_ch(spi_fd, CHANNEL_Y, 250000);
            restZ = hal_spi_adc_read_ch(spi_fd, CHANNEL_Z, 250000);
        }
        printf("Accel Calibrated: X=%d, Y=%d, Z=%d\n", restX, restY, restZ);
    } else {
        perror("Accel: Failed to open SPI");
    }
}

void Accel_cleanup(void) {
    hal_spi_adc_close(spi_fd);
    spi_fd = -1;
}

void Accel_readAndPlay(void) {
    if (spi_fd < 0) return;

    // this event for Jitter Analysis
    Period_markEvent(PERIOD_EVENT_ACCEL_READ);

    long long now = getTimeMs();

    // Read Raw Values
    int x = hal_spi_adc_read_ch(spi_fd, CHANNEL_X, 250000);
    int y = hal_spi_adc_read_ch(spi_fd, CHANNEL_Y, 250000);
    int z = hal_spi_adc_read_ch(spi_fd, CHANNEL_Z, 250000);

    
    // --- X Axis (Snare) ---
    if (abs(x - restX) > ACCEL_THRESHOLD) {
        if (now - lastTriggerX > DEBOUNCE_TIME_MS) {
            AudioMixer_queueSound(&snare); // Trigger Sound
            lastTriggerX = now;
      
        }
    }

    // --- Y Axis (Hi-Hat) ---
    if (abs(y - restY) > ACCEL_THRESHOLD) {
        if (now - lastTriggerY > DEBOUNCE_TIME_MS) {
            AudioMixer_queueSound(&hihat); // Trigger Sound
            lastTriggerY = now;
        }
    }

    // --- Z Axis (Base Drum) ---
    if (abs(z - restZ) > ACCEL_THRESHOLD) {
        if (now - lastTriggerZ > DEBOUNCE_TIME_MS) {
            AudioMixer_queueSound(&base); // Trigger Sound
            lastTriggerZ = now;
        }
    }
}