#include "hal/audioMixer.h"
#include "hal/periodTimer.h"
#include <alsa/asoundlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>
#include <alloca.h> 

#define SAMPLE_RATE 44100
#define NUM_CHANNELS 1
#define SAMPLE_SIZE (sizeof(short)) 

wavedata_t base;
wavedata_t hihat;
wavedata_t snare;

// Variables 
static snd_pcm_t *pcm_handle;
static pthread_t playbackThreadId;
static _Bool stopping = false;
static int volume = 80;
static int bpm = 120;
static int beatMode = 1; // 0=None, 1=Rock, 2=Custom

// Mutex for safe access to sound state
static pthread_mutex_t audioMutex = PTHREAD_MUTEX_INITIALIZER;

static void readWaveFileIntoMemory(const char *fileName, wavedata_t *pSound) {
    FILE *file = fopen(fileName, "rb");
    if (!file) {
        fprintf(stderr, "ERROR: Unable to open file %s\n", fileName);
        exit(1);
    }

    // Get file size
    fseek(file, 0, SEEK_END);
    int fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Skip Header 
    int headerSize = 44;
    int dataSize = fileSize - headerSize;

    // Allocate memory
    pSound->numSamples = dataSize / sizeof(short);
    pSound->pData = malloc(dataSize);
    pSound->currentIdx = 0;
    pSound->isPlaying = 0;

    // Read Data
    fseek(file, headerSize, SEEK_SET);
    fread(pSound->pData, sizeof(short), pSound->numSamples, file);
    fclose(file);
}

// Mixing Algorithm
static void fillBuffer(short *buffer, int num_samples) {
    memset(buffer, 0, num_samples * sizeof(short)); // Start with silence

    pthread_mutex_lock(&audioMutex);
    for (int i = 0; i < num_samples; i++) {
        int sum = 0;

        // Base 
        if (base.isPlaying) {
            sum += base.pData[base.currentIdx++];
            if (base.currentIdx >= base.numSamples) base.isPlaying = 0;
        }
        // Hi-Hat 
        if (hihat.isPlaying) {
            sum += hihat.pData[hihat.currentIdx++];
            if (hihat.currentIdx >= hihat.numSamples) hihat.isPlaying = 0;
        }
        // Snare 
        if (snare.isPlaying) {
            sum += snare.pData[snare.currentIdx++];
            if (snare.currentIdx >= snare.numSamples) snare.isPlaying = 0;
        }

        // Volume Control 
        sum = (sum * volume) / 100;

        if (sum > SHRT_MAX) sum = SHRT_MAX;
        if (sum < SHRT_MIN) sum = SHRT_MIN;

        buffer[i] = (short)sum;
    }
    pthread_mutex_unlock(&audioMutex);
}

// Playback Thread
static void* playbackThread(void* arg) {
    (void)arg;
    snd_pcm_sframes_t frames;
    
    unsigned long bufferSize = SAMPLE_RATE / 10; // 100ms buffer
    short *buffer = malloc(bufferSize * sizeof(short));

    while (!stopping) {
        // buffer with mixed audio
        fillBuffer(buffer, bufferSize);
        
        // event for Jitter Stats
        Period_markEvent(PERIOD_EVENT_AUDIO_BUFFER);

        // Write to ALSA
        frames = snd_pcm_writei(pcm_handle, buffer, bufferSize);
        if (frames < 0) {
            frames = snd_pcm_recover(pcm_handle, frames, 0);
            if (frames < 0) {
                fprintf(stderr, "ALSA write failed: %s\n", snd_strerror(frames));
            }
        }
    }
    free(buffer);
    return NULL;
}


static void* beatThread(void* arg) {
    (void)arg;
    while (!stopping) {
        int mode = AudioMixer_getMode();
        int currentBPM = AudioMixer_getBPM();
        
        // Calculate delay for half a beat
        long delayNs = (60.0 / currentBPM / 2.0) * 1000000000;
        struct timespec halfBeatWait = {0, delayNs};
        
        // Normalize timespec
        if (halfBeatWait.tv_nsec >= 1000000000) {
             halfBeatWait.tv_sec += halfBeatWait.tv_nsec / 1000000000;
             halfBeatWait.tv_nsec %= 1000000000;
        }

        if (mode == 1) { // Rock Beat
            // Beat 1.0
            AudioMixer_queueSound(&hihat); 
            AudioMixer_queueSound(&base);
            nanosleep(&halfBeatWait, NULL);
            // Beat 1.5
            AudioMixer_queueSound(&hihat);
            nanosleep(&halfBeatWait, NULL);
            // Beat 2.0
            AudioMixer_queueSound(&hihat); 
            AudioMixer_queueSound(&snare);
            nanosleep(&halfBeatWait, NULL);
            // Beat 2.5
            AudioMixer_queueSound(&hihat);
            nanosleep(&halfBeatWait, NULL);
            // Beat 3.0
            AudioMixer_queueSound(&hihat); 
            AudioMixer_queueSound(&base);
            nanosleep(&halfBeatWait, NULL);
            // Beat 3.5
            AudioMixer_queueSound(&hihat);
            nanosleep(&halfBeatWait, NULL);
            // Beat 4.0
            AudioMixer_queueSound(&hihat); 
            AudioMixer_queueSound(&snare);
            nanosleep(&halfBeatWait, NULL);
            // Beat 4.5
            AudioMixer_queueSound(&hihat);
            nanosleep(&halfBeatWait, NULL);
        } 
        else if (mode == 2) { // Custom Beat
            AudioMixer_queueSound(&base);
            AudioMixer_queueSound(&snare);
            nanosleep(&halfBeatWait, NULL);
        }
        else {
             // Mode 0: None (Silence)
             nanosleep(&halfBeatWait, NULL);
        }
    }
    return NULL;
}


void AudioMixer_init(void) {
    AudioMixer_setVolume(80);
    AudioMixer_setBPM(120);

    // Load WAV Files
    readWaveFileIntoMemory("wave-files/100051__menegass__gui-drum-bd-hard.wav", &base);
    readWaveFileIntoMemory("wave-files/100053__menegass__gui-drum-cc.wav", &hihat);
    readWaveFileIntoMemory("wave-files/100059__menegass__gui-drum-snare-soft.wav", &snare);

    // Open ALSA
    snd_pcm_open(&pcm_handle, "default", SND_PCM_STREAM_PLAYBACK, 0);
    snd_pcm_set_params(pcm_handle, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, 
                       NUM_CHANNELS, SAMPLE_RATE, 1, 500000); // 500ms latency

    // Start Threads
    pthread_create(&playbackThreadId, NULL, playbackThread, NULL);
    
    pthread_t beatThreadId;
    pthread_create(&beatThreadId, NULL, beatThread, NULL);
}

void AudioMixer_cleanup(void) {
    stopping = true;
    pthread_join(playbackThreadId, NULL);
    snd_pcm_close(pcm_handle);
    
    // Free WAV memory
    free(base.pData);
    free(hihat.pData);
    free(snare.pData);
}

void AudioMixer_queueSound(wavedata_t *pSound) {
    pthread_mutex_lock(&audioMutex);
    pSound->currentIdx = 0;
    pSound->isPlaying = 1;
    pthread_mutex_unlock(&audioMutex);
}

short *AudioMixer_getPcmData(int *size) {
    *size = 0;
    return NULL;
}

// Getters/Setters
void AudioMixer_setVolume(int v) { if(v>=0 && v<=100) volume = v; }
int AudioMixer_getVolume(void) { return volume; }

void AudioMixer_setBPM(int b) { if(b>=40 && b<=300) bpm = b; }
int AudioMixer_getBPM(void) { return bpm; }

void AudioMixer_setMode(int m) { beatMode = m; }
int AudioMixer_getMode(void) { return beatMode; }
void AudioMixer_nextMode(void) { 
    beatMode++;
    if (beatMode > 2) beatMode = 0;
}