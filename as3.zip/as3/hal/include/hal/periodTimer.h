#ifndef _PERIOD_TIMER_H_
#define _PERIOD_TIMER_H_


// Maximum number of timestamps to record for a given event.
#define MAX_EVENT_TIMESTAMPS (1024*4)

enum Period_whichEvent {
    PERIOD_EVENT_AUDIO_BUFFER,  // Mark when the AudioMixer finishes filling a buffer
    PERIOD_EVENT_ACCEL_READ,    // Mark when the Accelerometer finishes reading a sample
    NUM_PERIOD_EVENTS           // Must be the last element
};

typedef struct {
    int numSamples;         // Total samples taken
    double minPeriodInMs;   // Minimum time between events
    double maxPeriodInMs;   // Maximum time between events
    double avgPeriodInMs;   // Average time between events
} Period_statistics_t;

// Initialize the module's data structures.
void Period_init(void);

// Cleanup resources (if any).
void Period_cleanup(void);

// Record the current time as a timestamp for the indicated event.
// Call this inside your periodic threads (Audio thread, Input thread).
void Period_markEvent(enum Period_whichEvent whichEvent);

// Compute statistics for the event and clear the history.
// Call this once per second from your main thread to print stats.
void Period_getStatisticsAndClear(
    enum Period_whichEvent whichEvent,
    Period_statistics_t *pStats
);

#endif