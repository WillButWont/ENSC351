#ifndef HAL_UDPSERVER_H
#define HAL_UDPSERVER_H

#include <stdbool.h>


int UdpServer_init(int port, volatile bool* stopFlag);

/**
 * Stops the server thread and closes the socket.
 */
void UdpServer_cleanup(void);

#endif