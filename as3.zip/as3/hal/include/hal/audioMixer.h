#ifndef AUDIO_MIXER_H
#define AUDIO_MIXER_H

typedef struct {
    int numSamples;
    short *pData;
    int currentIdx;
    _Bool isPlaying;
} wavedata_t;

// Exposed so main.c, udpServer.c, and accelerometer.c can access them
extern wavedata_t base;
extern wavedata_t hihat;
extern wavedata_t snare;

void AudioMixer_init(void);
void AudioMixer_cleanup(void);

// Volume: 0 to 100
void AudioMixer_setVolume(int newVolume);
int AudioMixer_getVolume(void);

// BPM: 40 to 300
void AudioMixer_setBPM(int newBPM);
int AudioMixer_getBPM(void);

// Mode: 0=None, 1=Rock, 2=Custom
void AudioMixer_nextMode(void); // Cycle to next mode
void AudioMixer_setMode(int mode); // Set specific mode
int AudioMixer_getMode(void);

// Queue a sound to be played by the background mixer
void AudioMixer_queueSound(wavedata_t *pSound);

// Get access to the read-only audio buffer (for analysis if needed)
short *AudioMixer_getPcmData(int *size);

#endif // AUDIO_MIXER_H