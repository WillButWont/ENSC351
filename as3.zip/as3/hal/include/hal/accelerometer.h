#ifndef HAL_ACCELEROMETER_H
#define HAL_ACCELEROMETER_H

// Initialize the accelerometer (opens SPI handle)
void Accel_init(void);

// Close resources
void Accel_cleanup(void);

// Poll the accelerometer, detect shakes, and trigger audio.
// Call this function periodically from your input thread.
void Accel_readAndPlay(void);

#endif