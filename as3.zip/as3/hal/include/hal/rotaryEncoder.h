#ifndef ROTARYENCODER_H_
#define ROTARYENCODER_H_

/**
 * Initializes the rotary encoder and the push button.
 * pin_a: GPIO offset for Encoder A 
 * pin_b: GPIO offset for Encoder B
 * pin_btn: GPIO offset for the Push Button
 */
void Rotary_init(const char* chip, unsigned pin_a, unsigned pin_b, unsigned pin_btn);


void Rotary_cleanup(void);

#endif