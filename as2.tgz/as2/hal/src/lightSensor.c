#include "hal/lightSensor.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h> // [cite: 697]
#include <stdint.h>             // [cite: 693]

// --- Configuration from SPI Guide ---
#define SPI_DEVICE "/dev/spidev0.0"     // [cite: 729]
static uint8_t spi_mode = 0;            // [cite: 730, 736]
static uint8_t spi_bits = 8;            // [cite: 731, 742]
static uint32_t spi_speed = 250000;     // [cite: 732, 743]

// --- Configuration from previous file ---
#define ADC_VOLTAGE_REF 1.8
#define ADC_MAX_READING 4095.0 // 12-bit ADC [cite: 725]

static int spi_fd = -1;

/**
 * - Reads a 12-bit value from a specific ADC channel.
 * This function is based on the read_ch function from the guide. [cite: 698-725]
 * - ch The ADC channel to read (0-7).
 * @return The 12-bit raw ADC value, or -1 on failure.
 */
static int read_adc_channel(int ch) {
    if (spi_fd < 0) return -1;
    
    // 3-byte command to send to the MCP3208
    // This format is specific to the MCP3208 datasheet
    uint8_t tx[3] = {
        (uint8_t)(0x06 | ((ch & 0x04) >> 2)), // Start bit, SGL=1, D2
        (uint8_t)((ch & 0x03) << 6),          // D1, D0, then 6 bits of 0
        0x00                                 // 8 more bits of 0
    }; // [cite: 709, 711]

    // Receive buffer
    uint8_t rx[3] = {0}; // [cite: 712]

    // Data transfer structure
    struct spi_ioc_transfer tr = {
        .tx_buf = (unsigned long)tx,
        .rx_buf = (unsigned long)rx,
        .len = 3,
        .speed_hz = spi_speed,
        .bits_per_word = spi_bits,
        .cs_change = 0,
    }; // [cite: 714-720]

    // Send the SPI message
    if (ioctl(spi_fd, SPI_IOC_MESSAGE(1), &tr) < 1) { // [cite: 722]
        perror("Error: SPI_IOC_MESSAGE");
        return -1;
    }

    // Parse the 12-bit result from the rx buffer
    // The result is in the last 12 bits of the 24-bit transfer
    return ((rx[1] & 0x0F) << 8) | rx[2]; // [cite: 725]
}


int hal_lightSensor_init(void) {
    // Open the SPI device file
    spi_fd = open(SPI_DEVICE, O_RDWR); // [cite: 734]
    if (spi_fd < 0) {
        perror("Error opening SPI device"); // [cite: 737]
        return -1;
    }

    // --- Configure SPI ---
    // Set SPI mode
    if (ioctl(spi_fd, SPI_IOC_WR_MODE, &spi_mode) == -1) { // [cite: 737]
        perror("Error setting SPI mode");
        return -1;
    }
    // Set bits per word
    if (ioctl(spi_fd, SPI_IOC_WR_BITS_PER_WORD, &spi_bits) == -1) { // [cite: 742]
        perror("Error setting bits per word");
        return -1;
    }
    // Set max speed
    if (ioctl(spi_fd, SPI_IOC_WR_MAX_SPEED_HZ, &spi_speed) == -1) { // [cite: 743]
        perror("Error setting SPI speed");
        return -1;
    }

    return 0;
}

void hal_lightSensor_cleanup(void) {
    if (spi_fd >= 0) {
        close(spi_fd); // [cite: 754]
        spi_fd = -1;
    }
}

double hal_lightSensor_getVoltage(void) {
    if (spi_fd < 0) {
        fprintf(stderr, "Error: SPI not initialized.\n");
        return -1.0;
    }

    // Read from ADC Channel 0
    int raw_value = read_adc_channel(0); // [cite: 747]
    if (raw_value < 0) {
        fprintf(stderr, "Error reading from ADC channel.\n");
        return -1.0;
    }

    // Convert the 12-bit raw value (0-4095) to voltage
    double voltage = (raw_value / ADC_MAX_READING) * ADC_VOLTAGE_REF;
    return voltage;
}

