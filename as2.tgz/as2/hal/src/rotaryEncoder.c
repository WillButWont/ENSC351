#include "hal/rotaryEncoder.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdatomic.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h>
#include <pthread.h>
#include <time.h>
#include <gpiod.h>

#define MIN_HZ 0
#define MAX_HZ 500
#define STEP_HZ 1

static pthread_t th;
static atomic_int running = 0;
static struct gpiod_line_request *rq = NULL;
unsigned offs[2];

// Utility function to sleep in milliseconds
static void sleep_ms(int ms) {
    struct timespec ts = {ms / 1000, (ms % 1000) * 1000000L};
    nanosleep(&ts, NULL);
}

// Clamps a value to be within the defined range [MIN_HZ, MAX_HZ]
static inline int clamp(int x) {
    if (x < MIN_HZ) return MIN_HZ;
    if (x > MAX_HZ) return MAX_HZ;
    return x;
}

// The polling loop for the encoder
void* loop(void* arg) {
    atomic_int *target_hz = (atomic_int *)arg;

    int A = gpiod_line_request_get_value(rq, offs[0]);
    int B = gpiod_line_request_get_value(rq, offs[1]);
    int prev = ((A & 1) << 1) | (B & 1);

    // Define the step map for detecting rotation direction
    static const signed char step_map[16] = { 0,-1,+1, 0, +1, 0, 0,-1, -1, 0, 0,+1, 0,+1,-1, 0 };

    int accum = 0;
    running = 1;

    while (atomic_load(&running)) {
        int a = gpiod_line_request_get_value(rq, offs[0]);
        int b = gpiod_line_request_get_value(rq, offs[1]);

        // Exit loop if an error occurs while reading the values
        if (a < 0 || b < 0) break;

        int curr = ((a & 1) << 1) | (b & 1);
        int delta = step_map[(prev << 2) | curr];

        if (delta) {
            accum += delta;  // ±1 per half-step
            if (accum >= 4) {  // One detent CW
                int v = atomic_load(target_hz) + STEP_HZ;
                atomic_store(target_hz, clamp(v));
                accum = 0;
            } else if (accum <= -4) {  // One detent CCW
                int v = atomic_load(target_hz) - STEP_HZ;
                atomic_store(target_hz, clamp(v));
                accum = 0;
            }
        }

        prev = curr;
        sleep_ms(1);
    }

    return NULL;
}

// Initializes the rotary encoder by setting up the GPIO lines and starting the polling thread
void encoder_init(const char* chip, unsigned a_off, unsigned b_off, atomic_int *target_hz) {
    struct gpiod_chip *c = gpiod_chip_open(chip);
    if (!c) {
        perror("Failed to open GPIO chip");
        return;
    }

    struct gpiod_line_settings *ls = gpiod_line_settings_new();
    gpiod_line_settings_set_direction(ls, GPIOD_LINE_DIRECTION_INPUT);
    gpiod_line_settings_set_bias(ls, GPIOD_LINE_BIAS_PULL_UP);

    struct gpiod_line_config *lc = gpiod_line_config_new();
    offs[0] = a_off;  // Pin A offset
    offs[1] = b_off;  // Pin B offset
    gpiod_line_config_add_line_settings(lc, offs, 2, ls);

    struct gpiod_request_config *rc = gpiod_request_config_new();
    gpiod_request_config_set_consumer(rc, "encoder");

    rq = gpiod_chip_request_lines(c, rc, lc);
    if (!rq) {
        perror("Failed to request GPIO lines");
        gpiod_chip_close(c);
        return;
    }

    // Free resources no longer needed
    gpiod_request_config_free(rc);
    gpiod_line_config_free(lc);
    gpiod_line_settings_free(ls);

    // Create the polling thread
    int err = pthread_create(&th, NULL, loop, target_hz);
    if (err) {
        perror("Failed to create thread");
        gpiod_line_request_release(rq);
        gpiod_chip_close(c);
        return;
    }
}

// Stops the encoder polling thread and releases GPIO resources
void encoder_stop(void) {
    if (!rq) return;

    atomic_store(&running, 0);
    pthread_join(th, NULL);  // Wait for the polling thread to finish
    gpiod_line_request_release(rq);  // Release the GPIO lines
    rq = NULL;
}
