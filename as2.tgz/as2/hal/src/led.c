#include "hal/led.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

// Using system() for simplicity to control GPIO
// Use GPIO 16 as requested
#define GPIO_PIN "16"
#define GPIO_DIR_PATH "/sys/class/gpio/gpio" GPIO_PIN "/direction"
#define GPIO_VAL_PATH "/sys/class/gpio/gpio" GPIO_PIN "/value"

// Helper to run shell commands
static int runCommand(const char* command) {
    int res = system(command);
    if (res != 0) {
        fprintf(stderr, "Error executing: %s\n", command);
    }
    return res;
}

int hal_led_init(void) {
    char buffer[100];
    
    // Export GPIO pin
    runCommand("echo " GPIO_PIN " > /sys/class/gpio/export");
    // Wait for udev to set permissions
    usleep(300 * 1000); 

    // Set direction to "out"
    sprintf(buffer, "echo out > %s", GPIO_DIR_PATH);
    if (runCommand(buffer) != 0) {
        fprintf(stderr, "Failed to set GPIO direction.\n");
        return -1;
    }
    
    return 0;
}

void hal_led_cleanup(void) {
    // Turn LED off
    hal_led_setOff();
    
    // Unexport GPIO pin
    runCommand("echo " GPIO_PIN " > /sys/class/gpio/unexport");
}

void hal_led_setOn(void) {
    int fd = open(GPIO_VAL_PATH, O_WRONLY);
    if (fd == -1) {
        perror("Error opening LED value file");
        return;
    }
    if (write(fd, "1", 1) == -1) {
        perror("Error writing to LED value file");
    }
    close(fd);
}

void hal_led_setOff(void) {
    int fd = open(GPIO_VAL_PATH, O_WRONLY);
    if (fd == -1) {
        perror("Error opening LED value file");
        return;
    }
    if (write(fd, "0", 1) == -1) {
        perror("Error writing to LED value file");
    }
    close(fd);
}