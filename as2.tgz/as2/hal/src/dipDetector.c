#include "hal/dipDetector.h"
#include <stdbool.h>

// Dip thresholds as per assignment
#define DIP_THRESHOLD_VOLTS 0.1   
#define HYSTERESIS_VOLTS 0.03     

int DipDetector_countDips(double* history, int historySize, double currentAverage) {
    int dipCount = 0;
    bool isCurrentlyDipped = false;

    // Calculate thresholds based on the current average
    double dipTriggerLevel = currentAverage - DIP_THRESHOLD_VOLTS;       
    double dipReleaseLevel = currentAverage - (DIP_THRESHOLD_VOLTS - HYSTERESIS_VOLTS); // = avg - 0.07V 

    for (int i = 0; i < historySize; i++) {
        double sample = history[i];

        if (!isCurrentlyDipped) {
            // Not in a dip, check if we should enter one
            if (sample < dipTriggerLevel) {
                isCurrentlyDipped = true;
                dipCount++; // Count this as a new dip
            }
        } else {
            // Currently in a dip, check if we should release
            if (sample > dipReleaseLevel) { 
                isCurrentlyDipped = false;
            }
        }
    }
    
    return dipCount;
}