#include "hal/blinker.h"
#include <gpiod.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <time.h>

// Thread variables and GPIO resources
static pthread_t th;
static atomic_int running = ATOMIC_VAR_INIT(0);  // Explicit initialization
static struct gpiod_line_request *rq = NULL;
static unsigned led_off_global = 0;

// Utility function to wait for a specific number of microseconds
static void uswait(long usec){
    struct timespec ts = { usec / 1000000, (long)(usec % 1000000) * 1000L };
    nanosleep(&ts, NULL);
}

// The blinking thread's main loop function
static void *loop(void *arg){
    atomic_int *hz = (atomic_int *)arg;
    running = 1;  // Start the blinking
    while (atomic_load(&running)) {
        int frequency = atomic_load(hz);
        
        if (frequency <= 0) {
            gpiod_line_request_set_value(rq, led_off_global, 0);
            uswait(50 * 1000);  // Small delay when blinking is disabled
            continue;
        }

        long period_us = 1000000L / frequency;
        long half_period_us = period_us / 2;

        // Blink LED
        gpiod_line_request_set_value(rq, led_off_global, 1);
        uswait(half_period_us);
        gpiod_line_request_set_value(rq, led_off_global, 0);
        uswait(half_period_us);
    }
    return NULL;
}

// Initialization function to set up GPIO and start the blinking thread
void Blinker_init(const char *chip, unsigned led_off, atomic_int *hz){
    led_off_global = led_off;

    // Open the GPIO chip
    struct gpiod_chip *chip_handle = gpiod_chip_open(chip);
    if (!chip_handle) {
        perror("Failed to open GPIO chip");
        return;
    }

    // Set up line settings for the LED GPIO
    struct gpiod_line_settings *line_settings = gpiod_line_settings_new();
    gpiod_line_settings_set_direction(line_settings, GPIOD_LINE_DIRECTION_OUTPUT);
    gpiod_line_settings_set_output_value(line_settings, 0);

    // Configure the line request
    struct gpiod_line_config *line_config = gpiod_line_config_new();
    gpiod_line_config_add_line_settings(line_config, &led_off, 1, line_settings);

    struct gpiod_request_config *request_config = gpiod_request_config_new();
    gpiod_request_config_set_consumer(request_config, "blinker");

    // Request the line for output
    rq = gpiod_chip_request_lines(chip_handle, request_config, line_config);
    if (!rq) {
        perror("Failed to request GPIO lines");
        gpiod_chip_close(chip_handle);
        return;
    }

    // Start the blinking thread
    pthread_create(&th, NULL, loop, hz);

    // Clean up settings (these are not needed after the line request is made)
    gpiod_request_config_free(request_config);
    gpiod_line_config_free(line_config);
    gpiod_line_settings_free(line_settings);
}

// Function to stop the blinking thread and release resources
void Blinker_stop(void){
    if (!rq) return;

    // Stop the blinking thread
    atomic_store(&running, 0);
    pthread_join(th, NULL);

    // Release the requested GPIO line and clean up
    gpiod_line_request_release(rq);
    rq = NULL;
}

