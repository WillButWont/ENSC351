#include "hal/sampler.h"
#include "hal/lightSensor.h"
#include "hal/periodTimer.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

#define INITIAL_BUFFER_CAPACITY 1200 // 1.2s worth of samples @ 1ms sleep

// Threading
static pthread_t samplerThreadId;
static pthread_mutex_t dataMutex = PTHREAD_MUTEX_INITIALIZER;
static volatile bool isStopping = false;

// Data buffers
static double* currentBuffer = NULL;
static int currentBufferSize = 0;
static int currentBufferCapacity = INITIAL_BUFFER_CAPACITY;

static double* historyBuffer = NULL;
static int historyBufferSize = 0;

// Statistics
static long long totalSamplesTaken = 0;
static double currentAverage = 0.0;
static bool isFirstSample = true;

// Sampler thread function
static void* samplerThread(void* arg) {
    (void)arg;
    struct timespec sleepTime = { .tv_sec = 0, .tv_nsec = 1000 * 1000 }; // 1ms [cite: 49]

    while (!isStopping) {
        // Mark event for jitter analysis [cite: 544]
        Period_markEvent(PERIOD_EVENT_SAMPLE_LIGHT);

        // Read sample
        double voltage = hal_lightSensor_getVoltage();
        if (voltage < 0) {
            // Handle read error (e.g., skip sample)
            nanosleep(&sleepTime, NULL);
            continue;
        }

        // Lock for data update
        pthread_mutex_lock(&dataMutex);
        {
            totalSamplesTaken++; // [cite: 50]

            // Compute exponential smoothing [cite: 53]
            if (isFirstSample) {
                currentAverage = voltage; // [cite: 58]
                isFirstSample = false;
            } else {
                currentAverage = (0.999 * currentAverage) + (0.001 * voltage); // [cite: 54]
            }

            // Add to current buffer
            if (currentBufferSize >= currentBufferCapacity) {
                // Resize buffer if full
                currentBufferCapacity *= 2;
                currentBuffer = realloc(currentBuffer, currentBufferCapacity * sizeof(double));
                if (!currentBuffer) {
                    perror("Error: realloc failed in samplerThread");
                    isStopping = true; // Stop the thread
                }
            }
            
            if (currentBuffer) {
                 currentBuffer[currentBufferSize++] = voltage;
            }
        }
        pthread_mutex_unlock(&dataMutex);

        nanosleep(&sleepTime, NULL); // [cite: 49]
    }
    return NULL;
}

void Sampler_init(void) {
    if (hal_lightSensor_init() != 0) {
        fprintf(stderr, "Error initializing light sensor, sampler not started.\n");
        return;
    }

    currentBuffer = malloc(INITIAL_BUFFER_CAPACITY * sizeof(double));
    historyBuffer = malloc(INITIAL_BUFFER_CAPACITY * sizeof(double));
    if (!currentBuffer || !historyBuffer) {
        perror("Error: malloc failed in Sampler_init");
        exit(1);
    }
    
    currentBufferSize = 0;
    historyBufferSize = 0;
    currentBufferCapacity = INITIAL_BUFFER_CAPACITY;
    isStopping = false;

    pthread_create(&samplerThreadId, NULL, samplerThread, NULL); // [cite: 44]
}

void Sampler_cleanup(void) {
    isStopping = true;
    pthread_join(samplerThreadId, NULL); // [cite: 62]

    free(currentBuffer);
    currentBuffer = NULL;
    free(historyBuffer);
    historyBuffer = NULL;

    hal_lightSensor_cleanup();
    pthread_mutex_destroy(&dataMutex);
}

void Sampler_moveCurrentDataToHistory(void) {
    pthread_mutex_lock(&dataMutex);
    {
        // Free the old history buffer
        free(historyBuffer);
        
        // Move current buffer to history [cite: 77]
        historyBuffer = currentBuffer;
        historyBufferSize = currentBufferSize;
        
        // Allocate a new current buffer
        currentBuffer = malloc(currentBufferCapacity * sizeof(double));
        if (!currentBuffer) {
            perror("Error: malloc failed in moveDataToHistory");
            isStopping = true; // Critical error, stop sampling
        }
        currentBufferSize = 0;
    }
    pthread_mutex_unlock(&dataMutex);
}

int Sampler_getHistorySize(void) {
    int size = 0;
    pthread_mutex_lock(&dataMutex);
    {
        size = historyBufferSize;
    }
    pthread_mutex_unlock(&dataMutex);
    return size;
}

double* Sampler_getHistory(int *size) {
    double* historyCopy = NULL;
    pthread_mutex_lock(&dataMutex);
    {
        *size = historyBufferSize;
        if (*size > 0) {
            historyCopy = malloc(*size * sizeof(double)); // [cite: 106]
            if (historyCopy) {
                memcpy(historyCopy, historyBuffer, *size * sizeof(double));
            }
        } else {
             *size = 0;
             historyCopy = NULL; // Return valid, empty pointer
        }
    }
    pthread_mutex_unlock(&dataMutex);
    return historyCopy; // Caller must free [cite: 108]
}

double Sampler_getAverageReading(void) {
    double avg = 0.0;
    pthread_mutex_lock(&dataMutex);
    {
        avg = currentAverage;
    }
    pthread_mutex_unlock(&dataMutex);
    return avg;
}

long long Sampler_getNumSamplesTaken(void) {
    long long count = 0;
    pthread_mutex_lock(&dataMutex);
    {
        count = totalSamplesTaken;
    }
    pthread_mutex_unlock(&dataMutex);
    return count;
}