#include "hal/udpServer.h"
#include "hal/sampler.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdbool.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#define MAX_MSG_LEN 1024
#define MAX_PACKET_DATA_LEN 1450 // [cite: 137]
#define HISTORY_VALUES_PER_LINE 10 // [cite: 135]

static pthread_t serverThreadId;
static volatile bool* isRunningFlag = NULL;
static int socketFd = -1;

// State for 'dips' and 'enter' commands
static int lastDipCount = 0;
static pthread_mutex_t dipMutex = PTHREAD_MUTEX_INITIALIZER;
static char lastCommand[MAX_MSG_LEN] = "";
static pthread_mutex_t lastCmdMutex = PTHREAD_MUTEX_INITIALIZER;


// Helper to send a reply string
static void sendReply(const char* reply, struct sockaddr_in* clientAddr, socklen_t clientLen) {
    sendto(socketFd, reply, strlen(reply), 0,
           (struct sockaddr*)clientAddr, clientLen);
}

// Handler for the 'history' command
static void handleHistoryCommand(struct sockaddr_in* clientAddr, socklen_t clientLen) {
    int historySize = 0;
    double* history = Sampler_getHistory(&historySize); // [cite: 106]

    if (historySize == 0) {
        sendReply("No history samples available.\n", clientAddr, clientLen);
        free(history);
        return;
    }

    char packetBuffer[MAX_PACKET_DATA_LEN + 1];
    char sampleStr[32]; 
    int packetLen = 0;

    for (int i = 0; i < historySize; i++) {
        // Format the sample: voltage, 3 decimal places, comma [cite: 134]
        sprintf(sampleStr, "%.3f,", history[i]);

        // Check if adding this sample will overflow the packet [cite: 140]
        if (packetLen + (int)strlen(sampleStr) >= MAX_PACKET_DATA_LEN) {
            // Send the current packet [cite: 136]
            packetBuffer[packetLen] = '\0';
            sendReply(packetBuffer, clientAddr, clientLen);
            packetLen = 0;
        }

        // Add the sample string to the packet
        strcpy(packetBuffer + packetLen, sampleStr);
        packetLen += strlen(sampleStr);

        // Add a newline every 10 numbers [cite: 135]
        if ((i + 1) % HISTORY_VALUES_PER_LINE == 0) {
            if (packetLen + 1 >= MAX_PACKET_DATA_LEN) {
                // Send if newline won't fit
                packetBuffer[packetLen] = '\0';
                sendReply(packetBuffer, clientAddr, clientLen);
                packetLen = 0;
            }
            strcpy(packetBuffer + packetLen, "\n");
            packetLen++;
        }
    }
    
    // Send any remaining data in the buffer
    if (packetLen > 0) {
        packetBuffer[packetLen] = '\0';
        sendReply(packetBuffer, clientAddr, clientLen);
    }
    
    free(history); // [cite: 108]
}

// Main server thread loop
static void* serverThread(void* arg) {
    (void)arg;
    struct sockaddr_in clientAddr;
    socklen_t clientLen = sizeof(clientAddr);
    char buffer[MAX_MSG_LEN];

    while (*isRunningFlag) {
        // Wait for a message
        int bytesRead = recvfrom(socketFd, buffer, MAX_MSG_LEN - 1, 0,
                                 (struct sockaddr*)&clientAddr, &clientLen);
        
        if (bytesRead < 0) {
            if (errno == EINTR) continue; // Interrupted, probably by cleanup
            perror("Error: recvfrom failed");
            continue;
        }
        buffer[bytesRead] = '\0';

        // --- Process Command ---
        char* command = buffer;
        char response[MAX_PACKET_DATA_LEN + 1];
        bool sendDefaultResponse = true;

        // Trim trailing newline
        command[strcspn(command, "\r\n")] = '\0';

        // Handle <enter> command [cite: 144]
        if (strlen(command) == 0) {
            pthread_mutex_lock(&lastCmdMutex);
            if (strlen(lastCommand) == 0) {
                strcpy(command, "unknown_blank"); // Treat as unknown [cite: 145]
            } else {
                strcpy(command, lastCommand);
            }
            pthread_mutex_unlock(&lastCmdMutex);
        } else {
            // Save this as the last command
            pthread_mutex_lock(&lastCmdMutex);
            strncpy(lastCommand, command, MAX_MSG_LEN);
            pthread_mutex_unlock(&lastCmdMutex);
        }

        // --- Command Parser ---
        if (strcmp(command, "help") == 0 || strcmp(command, "?") == 0) { // [cite: 119, 122]
            sprintf(response, "Accepted commands:\n"
                              " help, ?     : Show this help\n"
                              " count       : Get total samples taken\n"
                              " length      : Get samples from last second\n"
                              " dips        : Get dips from last second\n"
                              " history     : Get all samples from last second\n"
                              " stop        : Stop the program\n"
                              " <enter>     : Repeat last command\n");
        }
        else if (strcmp(command, "count") == 0) { // [cite: 123]
            long long count = Sampler_getNumSamplesTaken();
            sprintf(response, "# samples taken total: %lld\n", count); // [cite: 124]
        }
        else if (strcmp(command, "length") == 0) { // [cite: 124]
            int len = Sampler_getHistorySize();
            sprintf(response, "# samples taken last second: %d\n", len); // [cite: 125]
        }
        else if (strcmp(command, "dips") == 0) { // [cite: 125]
            pthread_mutex_lock(&dipMutex);
            sprintf(response, "# Dips: %d\n", lastDipCount); // [cite: 126]
            pthread_mutex_unlock(&dipMutex);
        }
        else if (strcmp(command, "history") == 0) { // [cite: 131]
            handleHistoryCommand(&clientAddr, clientLen); // [cite: 132]
            sendDefaultResponse = false; 
        }
        else if (strcmp(command, "stop") == 0) { // [cite: 139]
            sprintf(response, "Program terminating.\n");
            *isRunningFlag = false; // Signal main thread to stop [cite: 141]
        }
        else { // [cite: 146]
            if (strncmp(command, "help", 4) == 0 || strncmp(command, "?", 1) == 0) {
                 sprintf(response, "Accepted commands:\n...\n(Type 'help' for full list)\n"); // [cite: 149]
            } else {
                 sprintf(response, "Unknown command '%s'. Type 'help' for list.\n", command);
            }
        }
        
        if (sendDefaultResponse) {
            sendReply(response, &clientAddr, clientLen);
        }
    }
    return NULL;
}

int UdpServer_init(int port, volatile bool* stopFlag) {
    isRunningFlag = stopFlag;
    
    // Create socket
    socketFd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (socketFd < 0) {
        perror("Error creating socket");
        return -1;
    }
    
    // Configure server address
    struct sockaddr_in serverAddr;
    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(socketFd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        perror("Error binding socket");
        close(socketFd);
        return -1;
    }
    
    // Start listener thread [cite: 115]
    if (pthread_create(&serverThreadId, NULL, serverThread, NULL) != 0) {
        perror("Error creating UDP server thread");
        close(socketFd);
        return -1;
    }

    return 0;
}

void UdpServer_cleanup(void) {
    if (socketFd != -1) {
        // Stop the thread
        pthread_cancel(serverThreadId); 
        pthread_join(serverThreadId, NULL);
        
        // Close socket [cite: 142]
        close(socketFd);
        socketFd = -1;
    }
    pthread_mutex_destroy(&dipMutex);
    pthread_mutex_destroy(&lastCmdMutex);
}

void UdpServer_setDipCount(int count) {
    pthread_mutex_lock(&dipMutex);
    lastDipCount = count;
    pthread_mutex_unlock(&dipMutex);
}