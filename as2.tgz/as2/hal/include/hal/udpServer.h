#ifndef UDPSERVER_H_
#define UDPSERVER_H_

#include <stdbool.h>

/**
 * - Initializes and starts the UDP server on its own thread.
 *
 * - port The port number to listen on (e.g., 12345).
 * - stopFlag A pointer to a volatile bool. The server will
 * set this flag to true when the 'stop' command is received.
 * @return 0 on success, -1 on failure.
 */
int UdpServer_init(int port, volatile bool* stopFlag);

/**
 * - Cleans up and stops the UDP server thread.
 */
void UdpServer_cleanup(void);

/**
 * - Updates the dip count value that the server reports.
 * This is a thread-safe function to pass data to the UDP server thread.
 * - count The number of dips from the last second.
 */
void UdpServer_setDipCount(int count);

#endif