#ifndef BLINKER_H_
#define BLINKER_H_

#include <stdatomic.h>

/**
 * - Initializes and starts the LED blinking thread.
 *
 * - chip The GPIO chip path (e.g., "/dev/gpiochip0").
 * - led_off The GPIO line offset (pin number) for the LED.
 * - hz A pointer to an atomic int. The thread will read this
 *           value to determine the blinking frequency.
 */
void Blinker_init(const char *chip, unsigned led_off, atomic_int *hz);

/**
 * - Stops the LED blinking thread and releases GPIO resources.
 */
void Blinker_stop(void);

#endif

