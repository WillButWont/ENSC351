#ifndef HAL_LED_H_
#define HAL_LED_H_

/**
 * - Initializes the LED GPIO pin.
 * @return 0 on success, -1 on failure.
 */
int hal_led_init(void);

/**
 * - Cleans up and turns off the LED.
 */
void hal_led_cleanup(void);

/**
 * - Turns the LED on.
 */
void hal_led_setOn(void);

/**
 * - Turns the LED off.
 */
void hal_led_setOff(void);

#endif