#ifndef DIPDETECTOR_H_
#define DIPDETECTOR_H_

/**
 * - Analyzes a history of samples for light dips.
 *
 * - history Array of voltage samples.
 * - historySize The number of samples in the array.
 * - currentAverage The current exponentially smoothed average light level.
 * @return The number of dips detected in the history.
 */
int DipDetector_countDips(double* history, int historySize, double currentAverage);

#endif