// sampler.h
// Module to sample light Levels in the background (uses a thread).
//
// It continuously samples the Light Level, and stores it internally.
// It provides access to the samples it recorded during the previous
// complete second.
//
// The application will do a number of actions each second which must
// be synchronized (such as computing dips and printing to the screen). [cite: 90-91]
// To make easy to work with the data, the app must call
// Sampler_moveCurrentDataToHistory() each second to trigger this
// module to move the current samples into the history. [cite: 92-94]
#ifndef SAMPLER_H_
#define SAMPLER_H_

// Begin/end the background thread which samples Light Levels.
void Sampler_init(void); // [cite: 98]
void Sampler_cleanup(void); // [cite: 99]

// Must be called once every 1s.
// Moves the samples that it has been collecting this second into
// the history, which makes the samples available for reads (below).
void Sampler_moveCurrentDataToHistory(void); // [cite: 102]

// Get the number of samples collected during the previous complete second.
int Sampler_getHistorySize(void); // [cite: 104]

// Get a copy of the samples in the sample history.
// Returns a newly allocated array and sets size to be the
// number of elements in the returned array (output-only parameter). [cite: 106-107]
// The calling code must call free() on the returned pointer.
// Note: It provides both data and size to ensure consistency.
double* Sampler_getHistory(int *size); // [cite: 110]

// Get the average Light Level (not tied to the history).
double Sampler_getAverageReading(void); // [cite: 111]

// Get the total number of light Level samples taken so far.
long long Sampler_getNumSamplesTaken(void); // [cite: 112]

#endif