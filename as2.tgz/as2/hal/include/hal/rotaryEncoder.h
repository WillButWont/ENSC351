#ifndef ROTARYENCODER_H_
#define ROTARYENCODER_H_

#include <stdatomic.h>

/**
 * Initializes and starts the rotary encoder polling thread.
 * 
 * chip The GPIO chip path (e.g., "/dev/gpiochip0").
 * a_off The GPIO line offset (pin number) for pin A.
 * b_off The GPIO line offset (pin number) for pin B.
 * target_hz A pointer to an atomic integer. The thread will update this value 
 *                  when the knob is turned.
 */
void encoder_init(const char* chip, unsigned a_off, unsigned b_off, atomic_int *target_hz);

/**
 * - Stops the encoder polling thread and releases GPIO resources.
 */
void encoder_stop(void);

#endif  // ROTARYENCODER_H_
