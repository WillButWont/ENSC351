#ifndef HAL_LIGHTSENSOR_H_
#define HAL_LIGHTSENSOR_H_

/**
 * - Initializes the light sensor module.
 * Must be called before getVoltage().
 * @return 0 on success, -1 on failure.
 */
int hal_lightSensor_init(void);

/**
 * - Cleans up and closes the light sensor module.
 */
void hal_lightSensor_cleanup(void);

/**
 * - Reads the current light sensor and returns its value as a voltage.
 * Assumes a 1.8V ADC range and 12-bit resolution (0-4095).
 * @return The current voltage reading, or -1.0 on error.
 */
double hal_lightSensor_getVoltage(void);

#endif