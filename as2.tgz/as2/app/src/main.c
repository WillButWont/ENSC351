#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <stdatomic.h> 

#include "hal/sampler.h"
#include "hal/udpServer.h"
#include "hal/dipDetector.h"
#include "hal/rotaryEncoder.h"
#include "hal/blinker.h"       
#include "hal/periodTimer.h"

// Shared state
static volatile bool isRunning = true;
static atomic_int g_ledFrequency; 

// --- Signal Handler ---
static void handleSignal(int sig) {
    (void)sig;
    isRunning = false;
}

// --- Terminal Output ---
static void printTerminalOutput(int samplesLastSec, int freq, double avg, int dips, Period_statistics_t* stats) {
    // Line 1: Stats
    printf("#Smpl/s %-4d Flash @ %-3dHz\t", samplesLastSec, freq);
    printf("avg = %.3fV\t", avg);
    printf("dips = %-3d\t", dips);
    
    printf("Smpl ms[%.3f, %.3f] avg %.3f/%d\n",
           stats->minPeriodInMs, stats->maxPeriodInMs, stats->avgPeriodInMs, stats->numSamples);
    
    fflush(stdout);
}

static void printHistorySamples(double* history, int size) {
    // Line 2: 10 spaced samples
    if (size == 0) {
        printf("(No samples)\n");
    } else {
        int step = (size <= 10) ? 1 : (size - 1) / (10 - 1);
        if (step == 0) step = 1;

        for (int i = 0; i < 10; i++) {
            int index = i * step;
            if (index >= size) {
                index = size - 1; 
                if (i == 0) break; 
            }
            
            printf("%d:%.3f  ", index, history[index]);

            if (index == (size - 1)) {
                break; 
            }
        }
        printf("\n");
    }
    fflush(stdout);
}

// --- Main Function ---
int main(void) {
    // Register signal handler for graceful shutdown
    signal(SIGINT, handleSignal);
    signal(SIGTERM, handleSignal);

    printf("Starting Light Dip Detector...\n");

    // Set initial frequency
    atomic_store(&g_ledFrequency, 10); //

    // Initialize all modules
    Period_init();
    Sampler_init();
    if (UdpServer_init(12345, &isRunning) != 0) {
        fprintf(stderr, "Failed to start UDP server. Exiting.\n");
        return 1;
    }

    // --- YOUR PIN CONFIGURATION IS HERE ---
    
    // Init encoder thread (GPIO 5 & 6 on chip 2 on lines 15 & 17)
    // This matches your OUT A -> GPIO 5 and OUT B -> GPIO 6
    encoder_init("/dev/gpiochip2", 15, 17, &g_ledFrequency);

    // Init blinker thread (GPIO 16 on chip 2 online 7)
    // This matches your LED -> GPIO 16
    Blinker_init("/dev/gpiochip2", 7, &g_ledFrequency);
    
    // --- END OF PIN CONFIGURATION ---


    // --- Main 1-Second Loop ---
    while (isRunning) {
        // Sleep for 1 second
        sleep(1); 
        if (!isRunning) break;

        // 1. Trigger history swap in sampler
        Sampler_moveCurrentDataToHistory();

        // 2. Get all data needed for analysis and display
        int historySize = 0;
        double* historyData = Sampler_getHistory(&historySize);
        double currentAvg = Sampler_getAverageReading();
        
        // Read the atomic frequency value
        int currentFreq = atomic_load(&g_ledFrequency); 
        
        Period_statistics_t stats;
        Period_getStatisticsAndClear(PERIOD_EVENT_SAMPLE_LIGHT, &stats);

        // 3. Analyze data
        int dipCount = DipDetector_countDips(historyData, historySize, currentAvg);
        
        // 4. Update UDP server with new dip count
        UdpServer_setDipCount(dipCount);

        // 5. Print to terminal
        printTerminalOutput(historySize, currentFreq, currentAvg, dipCount, &stats);
        printHistorySamples(historyData, historySize);

        // 6. Clean up history data
        free(historyData);
    }

    // --- Shutdown ---
    printf("\nShutting down...\n");

    // Stop and clean up all modules
    Blinker_stop();       // Stop blinker thread
    encoder_stop();       // Stop encoder thread
    
    UdpServer_cleanup(); 
    Sampler_cleanup();
    Period_cleanup();

    printf("Cleanup complete. Goodbye.\n");
    return 0;
}